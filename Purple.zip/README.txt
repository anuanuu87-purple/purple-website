🔮 PURPLE AGI - INSTALLATION & SETUP GUIDE

Welcome to Purple! Follow these steps to get started.

STEP 1: PROVIDE AN API KEY
Purple requires a Groq API Key to power her brain.
1. Go to https://console.groq.com/keys and create a FREE account.
2. Generate an API Key and copy it.
3. Double-click the "Start Purple.command" file to launch her.
4. Click the Purple icon (💜) in your Mac's top menu bar.
5. Click "⚙️ Change API Key", paste your key, and click Save.

STEP 2: GRANT MAC PERMISSIONS
macOS will ask you to grant Terminal access to your Microphone and Accessibility. 
You MUST click "Allow" for Purple to hear you and control your Mac.
(If you missed the prompt, go to System Settings > Privacy & Security and enable Terminal).

STEP 3: HOW TO USE
- Press Option + P on your keyboard to speak to Purple.
- Click "🛑 Stop Purple" in the menu bar if you want her to stop talking or listening immediately.

TROUBLESHOOTING (If Purple makes an error):
- If Purple says "I am being rate limited": You have exceeded the free API quota. Wait 1 minute, or generate a new API key in the Groq console.
- If Purple says "My API key is invalid": Your key was entered incorrectly or expired. Use the menu bar to enter a new one.
- If macOS says "Cannot be opened because it is from an unidentified developer": Simply RIGHT-CLICK the "Start Purple.command" file, select "Open", and then click "Open" again.

Enjoy your new AI Assistant!