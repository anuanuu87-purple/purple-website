#!/bin/bash
cd "$(dirname "$0")"

echo "====================================================="
echo " 🔮 PURPLE AGI - INSTALLING DEPENDENCIES             "
echo "====================================================="

# Check if Python 3 is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed."
    echo "Please install Python 3 from https://www.python.org/downloads/ and run this file again."
    read -p "Press Enter to exit..."
    exit 1
fi

# Install requirements
echo "⏳ Downloading Purple's brain modules (this may take a minute on first run)..."
python3 -m pip install -r requirements.txt

echo "✅ Dependencies installed!"
echo "Starting Purple..."

# Run the compiled agent (Hides your source code)
python3 __pycache__/purple_agent.cpython-*.pyc