=====================================================
✦ PURPL3 OS AI — INSTALLATION & SETUP GUIDE
=====================================================

Welcome to PURPL3 OS AI! Follow these quick steps to get started.

-----------------------------------------------------
STEP 1: FIRST-TIME LAUNCH (BYPASS MACOS GATEKEEPER)
-----------------------------------------------------
Because PURPL3 OS AI is an indie developer tool, macOS will verify it on first run:

1. Double-click "Start Purple.command".
2. If macOS shows '"Start Purple.command" Not Opened', click "Done".
3. Open your Mac's System Settings (Apple Menu  > System Settings).
4. Go to "Privacy & Security" on the left sidebar.
5. Scroll down to the "Security" section. You will see:
   '"Start Purple.command" was blocked from use...'
6. Click "Open Anyway" and enter your Mac password or Touch ID.
7. Click "Open". 

(You only need to do this ONCE. After this, it launches instantly.)


-----------------------------------------------------
STEP 2: ENTER YOUR FREE API KEY
-----------------------------------------------------
PURPL3 OS AI uses a Bring-Your-Own-Key (BYOK) privacy model:

1. Go to https://console.groq.com/keys and create a free account.
2. Generate an API Key and copy it.
3. When PURPL3 OS AI launches, paste your key into the prompt box and click "Save".
   (You can also change it anytime from the top menu bar icon > ⚙️ Change API Key).


-----------------------------------------------------
STEP 3: GRANT MACOS PERMISSIONS
-----------------------------------------------------
When prompted by macOS, click "Allow" for:
- Microphone (to hear your commands)
- Accessibility (to automate Finder and local tasks)

If you miss any prompt, enable them in:
System Settings > Privacy & Security > Accessibility & Microphone.


-----------------------------------------------------
STEP 4: HOW TO USE
-----------------------------------------------------
- Press Option + P anywhere on your Mac to speak.
- PURPL3 includes 10 free trial voice commands.
- Click "🛑 Stop PURPL3" in the top menu bar to interrupt speech or cancel an action immediately.


-----------------------------------------------------
TROUBLESHOOTING
-----------------------------------------------------
- "Rate Limit Reached": Wait 60 seconds or generate a fresh key on console.groq.com.
- "Invalid API Key": Click the menu bar icon > "⚙️ Change API Key" to re-paste your key.
- Chrome automation not responding: Ensure Google Chrome is installed on your Mac.